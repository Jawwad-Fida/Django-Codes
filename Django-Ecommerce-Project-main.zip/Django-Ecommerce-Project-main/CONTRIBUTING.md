This is a project that I created when I was learning Django for the first time. 
If there are any security vulnerabilities, you may submit a pull request to contribute. 
