from django.contrib import admin
from django.contrib.contenttypes.admin import GenericTabularInline
# Combine features from the two plugin apps --> store and tag

from store.admin import ProductAdmin
from store.models import Product
from tags.models import TaggedItem

# Register your models here.


# Inline class for Tag
class TagInline(GenericTabularInline):
    autocomplete_fields = ['tag']
    model = TaggedItem

# Create a new productadmin which extends the old one


class CustomProductAdmin(ProductAdmin):
    inlines = ['TagInline']


# unregister the old one
admin.site.unregister(Product)

# register the new one
admin.site.register(Product, CustomProductAdmin)
