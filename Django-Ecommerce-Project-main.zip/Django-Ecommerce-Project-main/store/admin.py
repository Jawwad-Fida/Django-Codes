from django.contrib import admin, messages
from django.http import HttpRequest
from django.db.models import Count
# All the code for customizing admin panel in app
from django.utils.html import format_html, urlencode
from django.urls import reverse
from django.db.models.query import QuerySet

# Register your models here - store app/admin.py
from . import models

# Google Django Model Admin --> see complete list of options to customize admin panel

# Filter Products with no inventory


class InventoryFilter(admin.SimpleListFilter):
    title = 'inventory'  # Will come after By
    parameter_name = 'inventory'  # will come in url query string ?

    # 2 methods

    # lookup --> display types of filter in the boxes
    def lookups(self, request, model_admin):
        # return a list of tuples representing each filter in the box
        return [('<10', 'Low')]
        return super().lookups(request, model_admin)

    # query set --> apply filtering logic selected by user
    def queryset(self, request, queryset: QuerySet):
        # from django.db.models.query import QuerySet
        if self.value() == '<10':
            return queryset.filter(inventory__lt=10)


class CollectionAdmin(admin.ModelAdmin):
    list_display = ['title', 'products_count']
    search_fields = ['title']
    # products_count --> custom field. it does not exist in the model class. So we need to override and annotate

    @admin.display(ordering='products_count')  # sort products by their number
    def products_count(self, collection):
        # from django.utils.html import format_html
        # {} will be replaced by the 2nd parameter
        # return format_html('<a href="http://google.com">{}</a>',collection.products_count)

        # To return urls from admin page, we can't hardcode them because they will change
        # from django.urls import reverse
        # reverse('admin:app_model_page')
        # Append a query string for filtering using --> ?
        # to encode a query string --> from django.utils.html import format_html, urlencode
        # urlencode takes in a dict argument (key-value pairs)
        url = (
            reverse('admin:store_product_changelist')
            + '?'
            + urlencode({
                'collection__id': str(collection.id)
            }))
        return format_html('<a href="{}">{}</a>', url, collection.products_count)

        # return collection.products_count

    def get_queryset(self, request):
        # in base class, get_queryset() returns all objects of the model
        return super().get_queryset(request).annotate(
            products_count=Count('product')
        )


class ProductAdmin(admin.ModelAdmin):
    # specify how we want to view and edit our products
    #inlines = [TagInline]
    autocomplete_fields = ['collection']

    actions = ['clear_inventory']
    list_display = ['title', 'unit_price',
                    'inventory_status', 'collection_title']
    list_editable = ['unit_price']  # can edit unit price in admin panel
    list_filter = ['collection', 'last_update', InventoryFilter]
    list_per_page = 10  # 10 products per page
    list_select_related = ['collection']  # list of fields to load initially

    def collection_title(self, product):
        return product.collection.title

    @admin.display(ordering='inventory')  # sorting using a descriptor
    def inventory_status(self, product):
        # e.g a new column where --> if products < 10: Low, else: Ok (Inventory status)
        if product.inventory < 10:
            return 'Low'
        return 'Ok'

    # this will show in the drop down list
    @admin.action(description='Clear Inventory')
    # request --> http request,
    # queryset --> list of objects selected by user
    def clear_inventory(self, request, queryset):
        updated_count = queryset.update(inventory=0)
        # send a message to user (success message)
        # from django.contrib import messages
        self.message_user(
            request, f'{updated_count} products were successfully deleted.', messages.SUCCESS
        )


class CustomerAdmin(admin.ModelAdmin):
    list_display = ['first_name', 'last_name', 'membership']
    list_editable = ['membership']
    list_per_page = 10
    # search fields with lookup types
    ordering = ['first_name', 'last_name']
    search_fields = ['first_name__istartswith', 'last_name__istartswith']

# Inclass class to manage orders


class OrderItemInline(admin.TabularInline):
    #autocomplete_fields = ['product']
    min_num = 1  # min number
    max_num = 10  # max number
    model = models.OrderItem
    extra = 0  # remove extra placeholders


class OrderAdmin(admin.ModelAdmin):
    autocomplete_fields = ['customer']
    list_display = ['id', 'placed_at', 'customer']  # customer is related field
    inlines = [OrderItemInline]
    list_per_page = 10


admin.site.register(models.Collection, CollectionAdmin)

# pass in the class when registering the model
admin.site.register(models.Product, ProductAdmin)

admin.site.register(models.Customer, CustomerAdmin)

admin.site.register(models.Order, OrderAdmin)
